<?php

defined( 'ABSPATH' ) || exit;

interface The7_Option_Field_Container_Interface {
	public function closing_tag();
}